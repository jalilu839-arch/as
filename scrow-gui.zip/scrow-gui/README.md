# Scrow GUI (radial wheel + frosted panels)

Rebuild of the click GUI to match the reference video: petal wheel with player head and badge, frosted module and
settings panels, search (Ctrl+F), bottom quick buttons, falling flakes, blurred backdrop. Colors come from
`scrow_logo.png` (ice cyan / white) and live in `Theme.java`.

## Status
- `dev.scrow.gui.*` (all menu logic, layout, animation, input): plain Java. Compiled and run here; see `preview/*.png`.
- `dev.scrow.gui.mc.*` (Screen, drawing fallback, sounds): written for 1.21.11 Mojang names but NOT compiled here
  (no Minecraft jars). Expect small renames, e.g. `Identifier`/`ResourceLocation`, the 1.21.9+ input event classes,
  `GuiGraphics.pose()`.
- `McDraw` is a non-anti-aliased fallback. For the final look, implement the shape methods of `Draw2D` with your
  existing `shape_aa` / `shape_aa_frost` shaders and `gui.ttf` icon glyphs.
- Sounds in `assets/scrowgui/sounds/ui/` are synthesized originals (open, close, hover, click, toggle on/off),
  not ripped from the video.

## Hooking it up (this is the only place your modules come in)
1. Copy `src/main/java/dev/scrow/gui` and `src/main/resources/assets/scrowgui` into your project.
2. Implement `Model.ModuleView` (and `ToggleSetting` / `SliderSetting` / `ChoiceSetting`) over your own modules.
3. `mc.setScreen(new ScrowScreen("Atmosphere", "Scrow", categories, buttons));`

Controls: click a petal for its modules, click a row to toggle, right-click or `>` for settings, drag sliders,
Ctrl+F to search, Esc to step back / close.
