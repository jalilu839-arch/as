package dev.scrow.gui;

/** Colors taken from scrow_logo.png (ice cyan / white). Change here to re-theme everything. */
public final class Theme {
    private Theme() {}

    public static final int ACCENT       = 0xFFD0F0F0; // rim, glow, icons
    public static final int ACCENT_MID   = 0xFF90D0F0;
    public static final int ACCENT_DEEP  = 0xFF70B0D0; // switches, slider fill
    public static final int TEXT         = 0xFFFFFFFF;
    public static final int TEXT_DIM     = 0xFFA9C4D0;

    public static final int PETAL_FILL   = 0x6690B4CC; // translucent frosted petal
    public static final int PETAL_HOVER  = 0x96B4DCF0;
    public static final int PANEL_FILL   = 0xC0121B26; // module / settings panels
    public static final int ROW_FILL     = 0x30FFFFFF;
    public static final int ROW_HOVER    = 0x4CFFFFFF;
    public static final int SWITCH_OFF   = 0xFF566878;
    public static final int BADGE_FILL   = 0xB070B0D0;

    public static int alpha(int argb, float a) {
        int al = Math.round(((argb >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, a)));
        return (al << 24) | (argb & 0xFFFFFF);
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int out = 0;
        for (int sh = 24; sh >= 0; sh -= 8) {
            int ca = (a >>> sh) & 0xFF, cb = (b >>> sh) & 0xFF;
            out |= (Math.round(ca + (cb - ca) * t) & 0xFF) << sh;
        }
        return out;
    }
}
