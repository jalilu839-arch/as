package dev.scrow.gui;

import java.util.List;

/** Thin views the menu reads. Implement these on top of your own module system (the GUI never touches module logic). */
public final class Model {
    private Model() {}

    public interface ModuleView {
        String name();
        boolean enabled();
        void setEnabled(boolean on);
        List<Setting> settings();
    }

    public interface Setting { String name(); }
    public interface ToggleSetting extends Setting { boolean get(); void set(boolean v); }
    public interface SliderSetting extends Setting {
        double min(); double max(); double get(); void set(double v); default double step() { return 0.01; }
    }
    public interface ChoiceSetting extends Setting { List<String> options(); int index(); void setIndex(int i); }

    public record Category(String name, String icon, List<ModuleView> modules) {}
    public record QuickButton(String label, Runnable action) {}
}
