package dev.scrow.gui;

/** Everything the menu needs to draw. Implement with your shape_aa / frost shaders, or use McDraw. */
public interface Draw2D {
    enum Align { LEFT, CENTER, RIGHT }

    void polygon(float[] pts, int argb);
    void polygonOutline(float[] pts, float width, int argb);
    /** Soft halo hugging the polygon edge. */
    void glow(float[] pts, float radius, int argb);
    void roundRect(float x, float y, float w, float h, float r, int argb);
    void roundRectOutline(float x, float y, float w, float h, float r, float width, int argb);
    void circle(float cx, float cy, float r, int argb);
    /** y is the vertical center of the text line. */
    void text(String s, float x, float y, float size, int argb, Align align);
    float textWidth(String s, float size);
    /** Category icon by id (map ids to glyphs in your gui.ttf). */
    void icon(String id, float cx, float cy, float size, int argb);
    void playerHead(float cx, float cy, float size);
    /** Blur + darken the world behind the menu. amount 0..1. */
    void frostBackdrop(float amount);
    void pushClip(float x, float y, float w, float h);
    void popClip();
}
