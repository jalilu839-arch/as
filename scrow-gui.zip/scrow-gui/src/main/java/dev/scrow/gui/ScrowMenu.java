package dev.scrow.gui;

import dev.scrow.gui.Draw2D.Align;
import java.util.*;

/** All menu state, animation, layout and input. No Minecraft types in here. */
public final class ScrowMenu {
    public enum Sound { OPEN, CLOSE, HOVER, CLICK, TOGGLE_ON, TOGGLE_OFF }
    public interface SoundSink { void play(Sound s, float pitch); }

    private enum Kind { MOD_TOGGLE, MOD_EXPAND, SET_TOGGLE, SET_SLIDER, SET_CHOICE, SEARCH, QUICK, PANEL }
    private record Hit(float x, float y, float w, float h, Kind kind, Object ref, int idx) {
        boolean in(float mx, float my) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    }

    public static final int KEY_ESC = 256, KEY_ENTER = 257, KEY_BACKSPACE = 259, KEY_F = 70;

    private final String playerName, badge, status;
    private final List<Model.Category> cats;
    private final List<Model.QuickButton> buttons;
    private final SoundSink sound;
    private final Particles particles = new Particles(70);
    private final Map<Object, Float> switchAnim = new IdentityHashMap<>();
    private final List<Hit> hits = new ArrayList<>();
    private final StringBuilder query = new StringBuilder();

    private int w, h; private float s;
    private RadialLayout radial;
    private float open, openTarget = 1, time;
    private float[] petalHover;
    private int hoverPetal = -1, hoverRow = -1;
    private int selCat = -1;
    private Model.ModuleView expanded;
    private float listAnim, setAnim, searchAnim, scroll;
    private boolean searching, closeRequested;
    private Model.SliderSetting dragging; private float dragX, dragW;

    public ScrowMenu(String playerName, String badge, String status,
                     List<Model.Category> cats, List<Model.QuickButton> buttons, SoundSink sound) {
        this.playerName = playerName; this.badge = badge; this.status = status;
        this.cats = cats; this.buttons = buttons; this.sound = sound;
        this.petalHover = new float[cats.size()];
        sound.play(Sound.OPEN, 1f);
    }

    public void resize(int w, int h) {
        this.w = w; this.h = h; this.s = h / 720f;
        this.radial = new RadialLayout(cats.size(), w / 2f, h / 2f + 2 * s, s);
    }

    public boolean isClosed() { return closeRequested && open < 0.02f; }
    public void requestClose() {
        if (!closeRequested) { closeRequested = true; openTarget = 0; sound.play(Sound.CLOSE, 1f); }
    }

    // ---------------------------------------------------------------- update / render

    public void update(float dt) {
        time += dt;
        open = Ease.approach(open, openTarget, dt, 11f);
        listAnim = Ease.approach(listAnim, selCat >= 0 || searching ? 1 : 0, dt, 14f);
        setAnim = Ease.approach(setAnim, expanded != null ? 1 : 0, dt, 14f);
        searchAnim = Ease.approach(searchAnim, searching ? 1 : 0, dt, 14f);
        for (int i = 0; i < petalHover.length; i++)
            petalHover[i] = Ease.approach(petalHover[i], i == hoverPetal ? 1 : 0, dt, 16f);
        for (var e : switchAnim.entrySet()) {
            float target = switchTarget(e.getKey());
            e.setValue(Ease.approach(e.getValue(), target, dt, 18f));
        }
        particles.update(dt);
    }

    private float switchTarget(Object o) {
        if (o instanceof Model.ModuleView m) return m.enabled() ? 1 : 0;
        if (o instanceof Model.ToggleSetting t) return t.get() ? 1 : 0;
        return 0;
    }

    private float sw(Object o) { return switchAnim.computeIfAbsent(o, this::switchTarget); }
    private float fs(float designSize) { return Math.max(7f, designSize * s); }
    private int a(int argb) { return Theme.alpha(argb, Ease.outCubic(open)); }

    public void render(Draw2D d, int mx, int my) {
        if (radial == null) return;
        hits.clear();
        float oe = Ease.outCubic(open);

        d.frostBackdrop(oe);
        particles.draw(d, w, h, s, oe);

        drawTopPill(d);
        drawWheel(d, mx, my);
        drawCenter(d);
        drawBottom(d, mx, my);
        drawPanels(d, mx, my);

        // hover tracking + hover sound
        int hp = RadialLayout.NONE;
        if (!overPanel(mx, my)) hp = radial.hit(mx, my);
        if (hp != hoverPetal && hp != RadialLayout.NONE) sound.play(Sound.HOVER, 1.2f);
        hoverPetal = hp;
    }

    private boolean overPanel(float mx, float my) {
        for (Hit hh : hits) if ((hh.kind == Kind.PANEL || hh.kind == Kind.QUICK || hh.kind == Kind.SEARCH) && hh.in(mx, my)) return true;
        return false;
    }

    private void drawTopPill(Draw2D d) {
        if (status == null || status.isEmpty()) return;
        float size = fs(11), tw = d.textWidth(status, size);
        float pw = tw + 46 * s, ph = 22 * s, x = w / 2f - pw / 2, y = 22 * s;
        d.roundRect(x, y, pw, ph, ph / 2, a(Theme.PANEL_FILL));
        d.roundRectOutline(x, y, pw, ph, ph / 2, Math.max(1f, 1.2f * s), a(Theme.alpha(Theme.ACCENT, 0.7f)));
        d.circle(x + 14 * s, y + ph / 2, 2.4f * s, a(Theme.ACCENT));
        d.text(status, w / 2f + 4 * s, y + ph / 2, size, a(Theme.TEXT), Align.CENTER);
    }

    private void drawWheel(Draw2D d, int mx, int my) {
        for (int i = 0; i < radial.count; i++) {
            float p = Ease.outBack(Ease.clamp01(open * 1.5f - i * 0.1f));
            float hv = petalHover[i];
            float sel = i == selCat ? 1 : 0;
            float k = (0.55f + 0.45f * p) * (1f + 0.05f * hv + 0.02f * sel);
            float[] poly = Geom.scaleAbout(radial.base[i], radial.cx, radial.cy, k);
            float[] c = Geom.scaleAbout(new float[] { radial.center[i][0], radial.center[i][1] }, radial.cx, radial.cy, k);
            float lit = Math.max(hv, sel * 0.8f);
            d.glow(poly, (14 + 10 * lit) * s, a(Theme.alpha(Theme.ACCENT, 0.55f + 0.4f * lit)));
            d.polygon(poly, a(Theme.mix(Theme.PETAL_FILL, Theme.PETAL_HOVER, lit)));
            d.polygonOutline(poly, Math.max(1.5f, (2.2f + 0.9f * lit) * s), a(Theme.alpha(Theme.ACCENT, 0.85f + 0.15f * lit)));
            Model.Category cat = cats.get(i);
            d.icon(cat.icon(), c[0], c[1] - 9 * s, 24 * s, a(Theme.TEXT));
            d.text(cat.name(), c[0], c[1] + 17 * s, fs(11), a(Theme.TEXT), Align.CENTER);
        }
    }

    private void drawCenter(Draw2D d) {
        float x = radial.headX, y = radial.headY, r = radial.headR;
        d.glow(circlePoly(x, y, r), 8 * s, a(Theme.alpha(Theme.ACCENT, 0.45f)));
        d.circle(x, y, r, a(Theme.alpha(Theme.PANEL_FILL, 0.85f)));
        d.playerHead(x, y, 54 * s);
        d.text(playerName, x, y + r + 11 * s, fs(10.5f), a(Theme.TEXT), Align.CENTER);
        if (badge != null && !badge.isEmpty()) {
            float size = fs(9), bw = d.textWidth(badge, size) + 16 * s, bh = 15 * s, by = y + r + 20 * s;
            d.roundRect(x - bw / 2, by, bw, bh, bh / 2, a(Theme.BADGE_FILL));
            d.roundRectOutline(x - bw / 2, by, bw, bh, bh / 2, Math.max(1f, s), a(Theme.alpha(Theme.ACCENT, 0.8f)));
            d.text(badge, x, by + bh / 2, size, a(Theme.TEXT), Align.CENTER);
        }
    }

    private static float[] circlePoly(float cx, float cy, float r) {
        float[] p = new float[64];
        for (int i = 0; i < 32; i++) {
            double an = i * Math.PI * 2 / 32;
            p[i * 2] = cx + (float) Math.cos(an) * r; p[i * 2 + 1] = cy + (float) Math.sin(an) * r;
        }
        return p;
    }

    private void drawBottom(Draw2D d, int mx, int my) {
        float bh = 22 * s, y = h - 42 * s - bh / 2;
        // search bar
        float sw = 236 * s, sx = w / 2f - sw / 2 - 30 * s;
        boolean hover = mx >= sx && mx <= sx + sw && my >= y && my <= y + bh;
        d.roundRect(sx, y, sw, bh, 7 * s, a(Theme.mix(Theme.PANEL_FILL, Theme.ROW_HOVER, hover || searching ? 0.5f : 0f)));
        d.roundRectOutline(sx, y, sw, bh, 7 * s, Math.max(1f, s), a(Theme.alpha(Theme.ACCENT, searching ? 0.9f : 0.35f)));
        String shown = searching ? query + (((int) (time * 2)) % 2 == 0 ? "|" : "") : "Search modules and settings";
        d.text(shown, sx + 12 * s, y + bh / 2, fs(9.5f), a(searching ? Theme.TEXT : Theme.TEXT_DIM), Align.LEFT);
        if (!searching) d.text("Ctrl+F", sx + sw - 10 * s, y + bh / 2, fs(8.5f), a(Theme.TEXT_DIM), Align.RIGHT);
        hits.add(new Hit(sx, y, sw, bh, Kind.SEARCH, null, 0));

        // quick buttons, right aligned
        float x = w - 22 * s;
        for (int i = buttons.size() - 1; i >= 0; i--) {
            String label = buttons.get(i).label();
            float size = fs(9.5f), bw = d.textWidth(label, size) + 24 * s;
            x -= bw;
            boolean hv = mx >= x && mx <= x + bw && my >= y && my <= y + bh;
            d.roundRect(x, y, bw, bh, 7 * s, a(Theme.mix(Theme.PANEL_FILL, Theme.ROW_HOVER, hv ? 0.9f : 0.2f)));
            d.roundRectOutline(x, y, bw, bh, 7 * s, Math.max(1f, s), a(Theme.alpha(Theme.ACCENT, hv ? 0.9f : 0.3f)));
            d.text(label, x + bw / 2, y + bh / 2, size, a(Theme.TEXT), Align.CENTER);
            hits.add(new Hit(x, y, bw, bh, Kind.QUICK, null, i));
            x -= 8 * s;
        }
    }

    // ---------------------------------------------------------------- panels

    private List<Model.ModuleView> visibleModules() {
        List<Model.ModuleView> out = new ArrayList<>();
        if (searching) {
            String q = query.toString().toLowerCase(Locale.ROOT).trim();
            for (Model.Category c : cats) for (Model.ModuleView m : c.modules()) {
                boolean match = q.isEmpty() || m.name().toLowerCase(Locale.ROOT).contains(q);
                if (!match) for (Model.Setting st : m.settings()) if (st.name().toLowerCase(Locale.ROOT).contains(q)) { match = true; break; }
                if (match) out.add(m);
            }
        } else if (selCat >= 0) out.addAll(cats.get(selCat).modules());
        return out;
    }

    private void drawPanels(Draw2D d, int mx, int my) {
        if (listAnim < 0.02f) return;
        List<Model.ModuleView> mods = visibleModules();
        float slide = (1f - Ease.outCubic(listAnim)) * -30 * s;
        float pa = Ease.outCubic(listAnim);
        float x = 70 * s + slide, y = 130 * s, pw = 190 * s, header = 30 * s, rowH = 24 * s;
        float maxH = h - y - 90 * s;
        float contentH = mods.size() * rowH + 8 * s;
        float ph = Math.min(header + contentH, maxH);
        float maxScroll = Math.max(0, header + contentH - ph);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        panel(d, x, y, pw, ph, searching ? "Search" : cats.get(selCat).name(), pa);
        hits.add(new Hit(x, y, pw, ph, Kind.PANEL, null, 0));
        d.pushClip(x, y + header, pw, ph - header);
        float ry = y + header + 4 * s - scroll;
        hoverRow = -1;
        for (int i = 0; i < mods.size(); i++, ry += rowH) {
            Model.ModuleView m = mods.get(i);
            if (ry + rowH < y + header || ry > y + ph) continue;
            float rx = x + 8 * s, rw = pw - 16 * s, rh = rowH - 4 * s;
            boolean hv = mx >= rx && mx <= rx + rw && my >= ry && my <= ry + rh && my >= y + header && my <= y + ph;
            boolean ex = m == expanded;
            d.roundRect(rx, ry, rw, rh, 6 * s, Theme.alpha(Theme.mix(Theme.ROW_FILL, Theme.ROW_HOVER, hv || ex ? 1f : 0f), pa));
            if (ex) d.roundRectOutline(rx, ry, rw, rh, 6 * s, Math.max(1f, s), Theme.alpha(Theme.ACCENT, 0.8f * pa));
            d.text(m.name(), rx + 9 * s, ry + rh / 2, fs(10), Theme.alpha(Theme.TEXT, pa), Align.LEFT);
            // chevron zone then switch
            float cw = 16 * s;
            d.text(">", rx + rw - cw / 2 - 2 * s, ry + rh / 2, fs(10), Theme.alpha(Theme.TEXT_DIM, pa), Align.CENTER);
            drawSwitch(d, rx + rw - cw - 30 * s, ry + rh / 2 - 6.5f * s, sw(m), pa);
            hits.add(new Hit(rx, ry, rw - cw, rh, Kind.MOD_TOGGLE, m, i));
            hits.add(new Hit(rx + rw - cw, ry, cw, rh, Kind.MOD_EXPAND, m, i));
            if (hv) hoverRow = i;
        }
        d.popClip();

        if (setAnim > 0.02f && expanded != null) drawSettings(d, mx, my, x + pw + 14 * s, y, pa * Ease.outCubic(setAnim));
    }

    private void drawSettings(Draw2D d, int mx, int my, float x, float y, float pa) {
        List<Model.Setting> list = expanded.settings();
        float pw = 214 * s, header = 30 * s;
        float total = 8 * s;
        for (Model.Setting st : list) total += rowHeight(st);
        float ph = Math.min(header + total, h - y - 90 * s);
        panel(d, x, y, pw, ph, expanded.name(), pa);
        hits.add(new Hit(x, y, pw, ph, Kind.PANEL, null, 0));
        d.pushClip(x, y + header, pw, ph - header);
        float ry = y + header + 4 * s;
        for (Model.Setting st : list) {
            float rh = rowHeight(st), rx = x + 8 * s, rw = pw - 16 * s;
            boolean hv = mx >= rx && mx <= rx + rw && my >= ry && my <= ry + rh - 4 * s;
            d.roundRect(rx, ry, rw, rh - 4 * s, 6 * s, Theme.alpha(Theme.mix(Theme.ROW_FILL, Theme.ROW_HOVER, hv ? 1f : 0f), pa));
            float cy = ry + (rh - 4 * s) / 2;
            if (st instanceof Model.ToggleSetting t) {
                d.text(t.name(), rx + 9 * s, cy, fs(9.5f), Theme.alpha(Theme.TEXT, pa), Align.LEFT);
                drawSwitch(d, rx + rw - 36 * s, cy - 6.5f * s, sw(t), pa);
                hits.add(new Hit(rx, ry, rw, rh - 4 * s, Kind.SET_TOGGLE, t, 0));
            } else if (st instanceof Model.SliderSetting sl) {
                float frac = (float) ((sl.get() - sl.min()) / (sl.max() - sl.min()));
                d.text(sl.name(), rx + 9 * s, ry + 9 * s, fs(9.5f), Theme.alpha(Theme.TEXT, pa), Align.LEFT);
                d.text(fmt(sl.get()), rx + rw - 9 * s, ry + 9 * s, fs(9), Theme.alpha(Theme.TEXT_DIM, pa), Align.RIGHT);
                float tx = rx + 9 * s, tw = rw - 18 * s, ty = ry + 21 * s;
                d.roundRect(tx, ty - 2 * s, tw, 4 * s, 2 * s, Theme.alpha(Theme.SWITCH_OFF, pa));
                d.roundRect(tx, ty - 2 * s, Math.max(4 * s, tw * frac), 4 * s, 2 * s, Theme.alpha(Theme.ACCENT_DEEP, pa));
                d.circle(tx + tw * frac, ty, 5 * s, Theme.alpha(Theme.ACCENT, pa));
                hits.add(new Hit(tx - 4 * s, ry + 12 * s, tw + 8 * s, 18 * s, Kind.SET_SLIDER, sl, 0));
            } else if (st instanceof Model.ChoiceSetting c) {
                d.text(c.name(), rx + 9 * s, cy, fs(9.5f), Theme.alpha(Theme.TEXT, pa), Align.LEFT);
                String val = c.options().get(c.index());
                float size = fs(9), bw = d.textWidth(val, size) + 14 * s;
                d.roundRect(rx + rw - bw - 6 * s, cy - 8 * s, bw, 16 * s, 8 * s, Theme.alpha(Theme.BADGE_FILL, pa));
                d.text(val, rx + rw - bw / 2 - 6 * s, cy, size, Theme.alpha(Theme.TEXT, pa), Align.CENTER);
                hits.add(new Hit(rx, ry, rw, rh - 4 * s, Kind.SET_CHOICE, c, 0));
            }
            ry += rh;
        }
        d.popClip();
    }

    private float rowHeight(Model.Setting st) { return (st instanceof Model.SliderSetting ? 36 : 24) * s; }

    private static String fmt(double v) { return Math.abs(v - Math.rint(v)) < 1e-6 ? String.valueOf((long) Math.rint(v)) : String.format(Locale.ROOT, "%.2f", v); }

    private void panel(Draw2D d, float x, float y, float pw, float ph, String title, float pa) {
        float[] box = { x, y, x + pw, y, x + pw, y + ph, x, y + ph };
        d.glow(box, 9 * s, Theme.alpha(Theme.ACCENT, 0.28f * pa));
        d.roundRect(x, y, pw, ph, 12 * s, Theme.alpha(Theme.PANEL_FILL, pa));
        d.roundRectOutline(x, y, pw, ph, 12 * s, Math.max(1f, 1.4f * s), Theme.alpha(Theme.ACCENT, 0.7f * pa));
        d.text(title, x + 14 * s, y + 15 * s, fs(11), Theme.alpha(Theme.TEXT, pa), Align.LEFT);
    }

    private void drawSwitch(Draw2D d, float x, float y, float t, float pa) {
        float tw = 26 * s, th = 13 * s;
        d.roundRect(x, y, tw, th, th / 2, Theme.alpha(Theme.mix(Theme.SWITCH_OFF, Theme.ACCENT_DEEP, t), pa));
        float kx = x + th / 2 + (tw - th) * t;
        d.circle(kx, y + th / 2, th / 2 - 1.8f * s, Theme.alpha(Theme.mix(0xFFC8D4DC, Theme.TEXT, t), pa));
    }

    // ---------------------------------------------------------------- input

    public boolean mouseClicked(float mx, float my, int button) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit hh = hits.get(i);
            if (!hh.in(mx, my) || hh.kind == Kind.PANEL) continue;
            switch (hh.kind) {
                case SEARCH -> { if (!searching) toggleSearch(); sound.play(Sound.CLICK, 1f); }
                case QUICK -> { sound.play(Sound.CLICK, 1f); buttons.get(hh.idx).action().run(); }
                case MOD_TOGGLE -> {
                    Model.ModuleView m = (Model.ModuleView) hh.ref;
                    if (button == 1) { toggleExpand(m); break; }
                    m.setEnabled(!m.enabled());
                    sound.play(m.enabled() ? Sound.TOGGLE_ON : Sound.TOGGLE_OFF, 1f);
                }
                case MOD_EXPAND -> toggleExpand((Model.ModuleView) hh.ref);
                case SET_TOGGLE -> {
                    Model.ToggleSetting t = (Model.ToggleSetting) hh.ref; t.set(!t.get());
                    sound.play(t.get() ? Sound.TOGGLE_ON : Sound.TOGGLE_OFF, 1f);
                }
                case SET_CHOICE -> {
                    Model.ChoiceSetting c = (Model.ChoiceSetting) hh.ref;
                    c.setIndex((c.index() + 1) % c.options().size()); sound.play(Sound.CLICK, 1.1f);
                }
                case SET_SLIDER -> { dragging = (Model.SliderSetting) hh.ref; dragX = hh.x + 4 * s; dragW = hh.w - 8 * s; applyDrag(mx); }
                default -> {}
            }
            return true;
        }
        for (Hit hh : hits) if (hh.kind == Kind.PANEL && hh.in(mx, my)) return true;
        int p = radial == null ? -1 : radial.hit(mx, my);
        if (p >= 0) {
            selCat = (selCat == p && !searching) ? -1 : p;
            searching = false; expanded = null; scroll = 0;
            sound.play(Sound.CLICK, 1f);
            return true;
        }
        if (selCat >= 0 || searching || expanded != null) { // click on empty space folds panels away
            if (expanded != null) expanded = null; else { selCat = -1; searching = false; }
            sound.play(Sound.CLICK, 0.8f);
            return true;
        }
        return false;
    }

    private void toggleExpand(Model.ModuleView m) {
        expanded = expanded == m ? null : m;
        sound.play(Sound.CLICK, 1.15f);
    }

    private void toggleSearch() {
        searching = !searching; query.setLength(0); scroll = 0; expanded = null;
        if (searching) selCat = -1;
    }

    public boolean mouseDragged(float mx, float my) { if (dragging != null) { applyDrag(mx); return true; } return false; }
    public boolean mouseReleased() { boolean was = dragging != null; dragging = null; return was; }

    private void applyDrag(float mx) {
        float f = Ease.clamp01((mx - dragX) / dragW);
        double v = dragging.min() + (dragging.max() - dragging.min()) * f;
        double st = dragging.step();
        if (st > 0) v = Math.round(v / st) * st;
        dragging.set(Math.max(dragging.min(), Math.min(dragging.max(), v)));
    }

    public boolean mouseScrolled(float delta) { scroll -= delta * 24 * s; return listAnim > 0.5f; }

    public boolean keyPressed(int key, boolean ctrl) {
        if (ctrl && key == KEY_F) { toggleSearch(); sound.play(Sound.CLICK, 1f); return true; }
        if (searching && key == KEY_BACKSPACE) { if (query.length() > 0) query.setLength(query.length() - 1); return true; }
        if (key == KEY_ESC) {
            if (searching) { searching = false; query.setLength(0); }
            else if (expanded != null) expanded = null;
            else if (selCat >= 0) selCat = -1;
            else requestClose();
            return true;
        }
        return searching;
    }

    public boolean charTyped(char c) {
        if (!searching || c < 32 || query.length() >= 32) return false;
        query.append(c); scroll = 0; return true;
    }
}
