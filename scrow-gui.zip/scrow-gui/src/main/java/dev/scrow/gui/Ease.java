package dev.scrow.gui;

public final class Ease {
    private Ease() {}
    public static float clamp01(float v) { return v < 0 ? 0 : Math.min(v, 1); }
    public static float outCubic(float t) { t = clamp01(t); float u = 1 - t; return 1 - u * u * u; }
    public static float outBack(float t) {
        t = clamp01(t); float c1 = 1.70158f, c3 = c1 + 1; float u = t - 1;
        return 1 + c3 * u * u * u + c1 * u * u;
    }
    /** Frame-rate independent smoothing toward a target. */
    public static float approach(float cur, float target, float dt, float speed) {
        return cur + (target - cur) * (1f - (float) Math.exp(-speed * dt));
    }
}
