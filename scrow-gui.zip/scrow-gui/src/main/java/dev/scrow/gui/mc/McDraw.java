package dev.scrow.gui.mc;

import dev.scrow.gui.Draw2D;
import java.util.Arrays;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.network.chat.Component;

/**
 * FALLBACK Draw2D for Minecraft 1.21.11 (Mojang names), rasterised with GuiGraphics.fill scanlines.
 * Not anti-aliased. For the final look, re-implement the shape methods with your shape_aa / shape_aa_frost shaders.
 * NOTE: written without a 1.21.11 compiler on hand - expect a few renames (GuiGraphics.pose(), PlayerFaceRenderer, etc).
 */
public final class McDraw implements Draw2D {
    private final GuiGraphics g;
    private final Font font;
    private final Runnable blur;
    private final float gs; // gui scale: we draw in device pixels for crisp edges

    public McDraw(GuiGraphics g, Runnable blurBackground) {
        this.g = g; this.blur = blurBackground;
        Minecraft mc = Minecraft.getInstance();
        this.font = mc.font; this.gs = (float) mc.getWindow().getGuiScale();
    }

    private void begin() { g.pose().pushMatrix(); g.pose().scale(1f / gs, 1f / gs); }
    private void end() { g.pose().popMatrix(); }
    private float[] dev(float[] p) { float[] o = new float[p.length]; for (int i = 0; i < p.length; i++) o[i] = p[i] * gs; return o; }

    @Override public void polygon(float[] pts, int argb) { begin(); fillPoly(dev(pts), argb); end(); }

    private void fillPoly(float[] p, int argb) {
        int n = p.length / 2; float min = Float.MAX_VALUE, max = -Float.MAX_VALUE;
        for (int i = 0; i < n; i++) { min = Math.min(min, p[i * 2 + 1]); max = Math.max(max, p[i * 2 + 1]); }
        float[] xs = new float[n];
        for (int y = (int) Math.floor(min); y <= (int) Math.ceil(max); y++) {
            float yc = y + 0.5f; int k = 0;
            for (int i = 0, j = n - 1; i < n; j = i++) {
                float yi = p[i * 2 + 1], yj = p[j * 2 + 1];
                if ((yi > yc) != (yj > yc)) xs[k++] = p[i * 2] + (yc - yi) * (p[j * 2] - p[i * 2]) / (yj - yi);
            }
            Arrays.sort(xs, 0, k);
            for (int i = 0; i + 1 < k; i += 2) g.fill(Math.round(xs[i]), y, Math.round(xs[i + 1]), y + 1, argb);
        }
    }

    @Override public void polygonOutline(float[] pts, float width, int argb) {
        begin(); float[] p = dev(pts); int n = p.length / 2; int wpx = Math.max(1, Math.round(width * gs));
        for (int i = 0; i < n; i++) segment(p[i * 2], p[i * 2 + 1], p[((i + 1) % n) * 2], p[((i + 1) % n) * 2 + 1], wpx, argb);
        end();
    }

    private void segment(float x0, float y0, float x1, float y1, int wpx, int argb) {
        int steps = Math.max(1, (int) (Math.hypot(x1 - x0, y1 - y0) / Math.max(1, wpx * 0.5f)));
        for (int i = 0; i <= steps; i++) {
            float t = i / (float) steps; int x = Math.round(x0 + (x1 - x0) * t - wpx / 2f), y = Math.round(y0 + (y1 - y0) * t - wpx / 2f);
            g.fill(x, y, x + wpx, y + wpx, argb);
        }
    }

    @Override public void glow(float[] pts, float radius, int argb) {
        int a = (argb >>> 24) & 0xFF;
        for (int i = 3; i >= 1; i--) {
            int al = a * (4 - i) / 14;
            polygonOutline(pts, radius * i / 3f * 0.9f, (al << 24) | (argb & 0xFFFFFF));
        }
    }

    @Override public void roundRect(float x, float y, float w, float h, float r, int argb) {
        begin(); x *= gs; y *= gs; w *= gs; h *= gs; r = Math.min(r * gs, Math.min(w, h) / 2);
        for (int row = 0; row < Math.round(h); row++) {
            float dy = row + 0.5f, edge = Math.min(dy, h - dy);
            float inset = edge >= r ? 0 : r - (float) Math.sqrt(Math.max(0, r * r - (r - edge) * (r - edge)));
            g.fill(Math.round(x + inset), Math.round(y) + row, Math.round(x + w - inset), Math.round(y) + row + 1, argb);
        }
        end();
    }

    @Override public void roundRectOutline(float x, float y, float w, float h, float r, float lw, int argb) {
        float[] p = new float[4 * 2 * 9]; int k = 0; float[][] c = { { x + w - r, y + r, -90 }, { x + w - r, y + h - r, 0 }, { x + r, y + h - r, 90 }, { x + r, y + r, 180 } };
        for (float[] cc : c) for (int i = 0; i <= 8; i++) { double an = Math.toRadians(cc[2] + 90.0 * i / 8); p[k++] = cc[0] + (float) Math.cos(an) * r; p[k++] = cc[1] + (float) Math.sin(an) * r; }
        polygonOutline(Arrays.copyOf(p, k), lw, argb);
    }

    @Override public void circle(float cx, float cy, float r, int argb) { roundRect(cx - r, cy - r, r * 2, r * 2, r, argb); }

    @Override public void text(String s, float x, float y, float size, int argb, Align align) {
        float k = size / 8f; float w = font.width(s) * k;
        float px = align == Align.CENTER ? x - w / 2 : align == Align.RIGHT ? x - w : x;
        g.pose().pushMatrix(); g.pose().translate(px, y - 4f * k); g.pose().scale(k, k);
        g.drawString(font, Component.literal(s), 0, 0, argb, false);
        g.pose().popMatrix();
    }

    @Override public float textWidth(String s, float size) { return font.width(s) * size / 8f; }

    /** Fallback: first letter. Replace with a glyph from assets/lithium/font/gui.ttf for real icons. */
    @Override public void icon(String id, float cx, float cy, float size, int argb) {
        text(id.isEmpty() ? "?" : id.substring(0, 1).toUpperCase(), cx, cy, size * 0.9f, argb, Align.CENTER);
    }

    @Override public void playerHead(float cx, float cy, float size) {
        var player = Minecraft.getInstance().player; if (player == null) return;
        PlayerFaceRenderer.draw(g, player.getSkin(), Math.round(cx - size / 2), Math.round(cy - size / 2), Math.round(size));
    }

    @Override public void frostBackdrop(float amount) {
        blur.run();
        g.fill(0, 0, g.guiWidth(), g.guiHeight(), (Math.round(110 * amount) << 24) | 0x0A101A);
    }

    @Override public void pushClip(float x, float y, float w, float h) { g.enableScissor(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h)); }
    @Override public void popClip() { g.disableScissor(); }
}
