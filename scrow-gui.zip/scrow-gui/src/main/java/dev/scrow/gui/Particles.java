package dev.scrow.gui;

import java.util.Random;

/** Slow falling flakes over the blurred world (the reference uses falling petals). */
final class Particles {
    private final int n;
    private final float[] x, y, vy, vx, r, ph;
    private final Random rnd = new Random(7);
    private float t;

    Particles(int n) {
        this.n = n; x = new float[n]; y = new float[n]; vy = new float[n]; vx = new float[n]; r = new float[n]; ph = new float[n];
        for (int i = 0; i < n; i++) { spawn(i); y[i] = rnd.nextFloat(); }
    }

    private void spawn(int i) {
        x[i] = rnd.nextFloat(); y[i] = -0.03f;
        vy[i] = 0.025f + rnd.nextFloat() * 0.05f; vx[i] = (rnd.nextFloat() - 0.5f) * 0.01f;
        r[i] = 0.7f + rnd.nextFloat() * 1.8f; ph[i] = rnd.nextFloat() * 6.28f;
    }

    void update(float dt) {
        t += dt;
        for (int i = 0; i < n; i++) {
            y[i] += vy[i] * dt; x[i] += (vx[i] + (float) Math.sin(t * 0.8f + ph[i]) * 0.004f) * dt;
            if (y[i] > 1.04f) spawn(i);
            if (x[i] < -0.02f) x[i] += 1.04f; else if (x[i] > 1.02f) x[i] -= 1.04f;
        }
    }

    void draw(Draw2D d, float w, float h, float s, float alpha) {
        for (int i = 0; i < n; i++) {
            float tw = 0.5f + 0.5f * (float) Math.sin(t * 1.7f + ph[i]);
            d.circle(x[i] * w, y[i] * h, r[i] * s, Theme.alpha(Theme.ACCENT, alpha * (0.25f + 0.5f * tw)));
        }
    }
}
