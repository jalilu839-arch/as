package dev.scrow.gui.mc;

import dev.scrow.gui.ScrowMenu.Sound;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.Identifier; // was ResourceLocation before 1.21.11
import net.minecraft.sounds.SoundEvent;

public final class McSounds {
    private McSounds() {}

    private static SoundEvent ev(String path) { return SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("scrowgui", path)); }
    private static final SoundEvent OPEN = ev("ui.open"), CLOSE = ev("ui.close"), HOVER = ev("ui.hover"),
        CLICK = ev("ui.click"), ON = ev("ui.toggle_on"), OFF = ev("ui.toggle_off");

    public static void play(Sound s, float pitch) {
        SoundEvent e = switch (s) { case OPEN -> OPEN; case CLOSE -> CLOSE; case HOVER -> HOVER; case CLICK -> CLICK; case TOGGLE_ON -> ON; case TOGGLE_OFF -> OFF; };
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(e, pitch, 0.6f));
    }
}
