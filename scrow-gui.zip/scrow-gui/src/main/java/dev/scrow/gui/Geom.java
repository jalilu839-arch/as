package dev.scrow.gui;

import java.util.Random;

public final class Geom {
    private Geom() {}

    /** Closed-polygon corner cutting: turns a few control points into a soft blob. */
    public static float[] chaikin(float[] p, int iters) {
        for (int it = 0; it < iters; it++) {
            int n = p.length / 2;
            float[] q = new float[n * 4];
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                float x0 = p[i * 2], y0 = p[i * 2 + 1], x1 = p[j * 2], y1 = p[j * 2 + 1];
                q[i * 4]     = 0.75f * x0 + 0.25f * x1;
                q[i * 4 + 1] = 0.75f * y0 + 0.25f * y1;
                q[i * 4 + 2] = 0.25f * x0 + 0.75f * x1;
                q[i * 4 + 3] = 0.25f * y0 + 0.75f * y1;
            }
            p = q;
        }
        return p;
    }

    /** One organic petal: an annular sector with bulged outer edge and soft corners. Angles in radians. */
    public static float[] petal(float cx, float cy, float r0, float r1, float a0, float a1, long seed) {
        Random rnd = new Random(seed);
        float am = (a0 + a1) / 2f;
        float[] rad = {
            r1 * (0.97f + j(rnd)), r1 * (1.03f + j(rnd)), r1 * (1.05f + j(rnd)), r1 * (1.03f + j(rnd)), r1 * (0.97f + j(rnd)),
            r0 * (1.00f + j(rnd)), r0 * (0.93f + j(rnd)), r0 * (1.00f + j(rnd))
        };
        float[] ang = {
            a0, a0 + (am - a0) * 0.5f, am, am + (a1 - am) * 0.5f, a1,
            a1, am, a0
        };
        float[] pts = new float[rad.length * 2];
        for (int i = 0; i < rad.length; i++) {
            pts[i * 2]     = cx + (float) Math.cos(ang[i]) * rad[i];
            pts[i * 2 + 1] = cy + (float) Math.sin(ang[i]) * rad[i];
        }
        return chaikin(pts, 4);
    }

    private static float j(Random r) { return (r.nextFloat() - 0.5f) * 0.04f; }

    public static boolean contains(float[] poly, float x, float y) {
        boolean in = false;
        int n = poly.length / 2;
        for (int i = 0, j = n - 1; i < n; j = i++) {
            float xi = poly[i * 2], yi = poly[i * 2 + 1], xj = poly[j * 2], yj = poly[j * 2 + 1];
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) in = !in;
        }
        return in;
    }

    public static float[] centroid(float[] poly) {
        float sx = 0, sy = 0; int n = poly.length / 2;
        for (int i = 0; i < n; i++) { sx += poly[i * 2]; sy += poly[i * 2 + 1]; }
        return new float[] { sx / n, sy / n };
    }

    public static float[] scaleAbout(float[] poly, float ox, float oy, float k) {
        float[] o = new float[poly.length];
        for (int i = 0; i < poly.length; i += 2) {
            o[i] = ox + (poly[i] - ox) * k;
            o[i + 1] = oy + (poly[i + 1] - oy) * k;
        }
        return o;
    }
}
