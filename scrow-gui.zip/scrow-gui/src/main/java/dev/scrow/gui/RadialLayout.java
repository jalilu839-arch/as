package dev.scrow.gui;

/** Geometry for the petal wheel. Everything scales with {@code s} (screen height / 720). */
public final class RadialLayout {
    public static final int NONE = -1;
    public final float cx, cy, s;
    public final int count;
    public final float[][] base;
    public final float[][] center;
    public final float headX, headY, headR;

    public RadialLayout(int count, float cx, float cy, float s) {
        this.count = count; this.cx = cx; this.cy = cy; this.s = s;
        this.base = new float[count][];
        this.center = new float[count][];
        float r0 = 66 * s, r1 = 208 * s;
        float span = (float) (2 * Math.PI / count);
        float gap = (float) Math.toRadians(7);
        // seam at the top: first petal sits up-left, like the reference wheel
        float start = (float) Math.toRadians(-90) - span;
        for (int i = 0; i < count; i++) {
            float a0 = start + span * i + gap / 2, a1 = start + span * (i + 1) - gap / 2;
            base[i] = Geom.petal(cx, cy, r0, r1, a0, a1, 1000L + i * 31L);
            center[i] = Geom.centroid(base[i]);
        }
        headX = cx; headY = cy - 22 * s; headR = 42 * s;
    }

    public int hit(float mx, float my) {
        for (int i = 0; i < count; i++) if (Geom.contains(base[i], mx, my)) return i;
        return NONE;
    }
}
