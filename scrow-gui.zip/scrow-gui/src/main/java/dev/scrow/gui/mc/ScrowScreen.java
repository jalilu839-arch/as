package dev.scrow.gui.mc;

import dev.scrow.gui.Model;
import dev.scrow.gui.ScrowMenu;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Thin Screen wrapper. Open with: mc.setScreen(new ScrowScreen("Atmosphere", "Scrow", categories, buttons)); */
public class ScrowScreen extends Screen {
    private final String status, badge;
    private final List<Model.Category> cats;
    private final List<Model.QuickButton> buttons;
    private ScrowMenu menu;
    private long last = System.nanoTime();

    public ScrowScreen(String status, String badge, List<Model.Category> cats, List<Model.QuickButton> buttons) {
        super(Component.literal("Scrow"));
        this.status = status; this.badge = badge; this.cats = cats; this.buttons = buttons;
    }

    @Override protected void init() {
        if (menu == null) menu = new ScrowMenu(minecraft.getUser().getName(), badge, status, cats, buttons, McSounds::play);
        menu.resize(width, height);
    }

    @Override public void render(GuiGraphics g, int mx, int my, float pt) {
        long now = System.nanoTime(); float dt = Math.min(0.1f, (now - last) / 1e9f); last = now;
        menu.update(dt);
        menu.render(new McDraw(g, () -> renderBlurredBackground(g)), mx, my);
        if (menu.isClosed()) minecraft.setScreen(null);
    }

    @Override public void renderBackground(GuiGraphics g, int mx, int my, float pt) { /* menu draws its own frosted backdrop */ }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void onClose() { menu.requestClose(); }

    @Override public boolean mouseClicked(MouseButtonEvent e, boolean dbl) { return menu.mouseClicked((float) e.x(), (float) e.y(), e.button()) || super.mouseClicked(e, dbl); }
    @Override public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) { return menu.mouseDragged((float) e.x(), (float) e.y()) || super.mouseDragged(e, dx, dy); }
    @Override public boolean mouseReleased(MouseButtonEvent e) { return menu.mouseReleased() || super.mouseReleased(e); }
    @Override public boolean mouseScrolled(double x, double y, double sx, double sy) { return menu.mouseScrolled((float) sy) || super.mouseScrolled(x, y, sx, sy); }
    @Override public boolean keyPressed(KeyEvent e) { return menu.keyPressed(e.key(), e.hasControlDown()) || super.keyPressed(e); }
    @Override public boolean charTyped(CharacterEvent e) { return menu.charTyped((char) e.codepoint()) || super.charTyped(e); }
}
