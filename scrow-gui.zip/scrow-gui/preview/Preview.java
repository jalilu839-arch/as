import dev.scrow.gui.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.io.File;
import java.util.*;
import java.util.List;
import javax.imageio.ImageIO;

/** Headless renderer: runs the real ScrowMenu through a Java2D Draw2D so the look can be checked without Minecraft. */
public class Preview {
    static final int W = 1280, H = 720;

    static class J2D implements Draw2D {
        final Graphics2D g; final BufferedImage world; final String head;
        J2D(Graphics2D g, BufferedImage world) { this.g = g; this.world = world; this.head = "head"; }
        Color c(int a) { return new Color((a >> 16) & 255, (a >> 8) & 255, (a) & 255, (a >>> 24) & 255); }
        Path2D path(float[] p) { Path2D.Float q = new Path2D.Float(); q.moveTo(p[0], p[1]); for (int i = 2; i < p.length; i += 2) q.lineTo(p[i], p[i + 1]); q.closePath(); return q; }
        public void polygon(float[] p, int a) { g.setColor(c(a)); g.fill(path(p)); }
        public void polygonOutline(float[] p, float w, int a) { g.setColor(c(a)); g.setStroke(new BasicStroke(w, 1, 1)); g.draw(path(p)); }
        public void glow(float[] p, float r, int a) {
            Path2D q = path(p);
            for (int i = 8; i >= 1; i--) {
                float f = i / 8f; int al = Math.round(((a >>> 24) & 255) * (1 - f) * 0.35f);
                g.setColor(c((al << 24) | (a & 0xFFFFFF))); g.setStroke(new BasicStroke(r * f * 2, 1, 1)); g.draw(q);
            }
        }
        public void roundRect(float x, float y, float w, float h, float r, int a) { g.setColor(c(a)); g.fill(new RoundRectangle2D.Float(x, y, w, h, r * 2, r * 2)); }
        public void roundRectOutline(float x, float y, float w, float h, float r, float lw, int a) { g.setColor(c(a)); g.setStroke(new BasicStroke(lw)); g.draw(new RoundRectangle2D.Float(x, y, w, h, r * 2, r * 2)); }
        public void circle(float cx, float cy, float r, int a) { g.setColor(c(a)); g.fill(new Ellipse2D.Float(cx - r, cy - r, r * 2, r * 2)); }
        public void text(String s, float x, float y, float size, int a, Align al) {
            g.setFont(new Font("SansSerif", Font.PLAIN, 1).deriveFont(size * 1.15f)); g.setColor(c(a));
            FontMetrics fm = g.getFontMetrics(); float w = fm.stringWidth(s);
            float px = al == Align.CENTER ? x - w / 2 : al == Align.RIGHT ? x - w : x;
            g.drawString(s, px, y + (fm.getAscent() - fm.getDescent()) / 2f);
        }
        public float textWidth(String s, float size) { g.setFont(new Font("SansSerif", Font.PLAIN, 1).deriveFont(size * 1.15f)); return g.getFontMetrics().stringWidth(s); }
        public void icon(String id, float cx, float cy, float size, int a) {
            g.setColor(c(a)); g.setStroke(new BasicStroke(size / 9f, 1, 1));
            float r = size / 2.4f;
            switch (id) {
                case "gear" -> { g.draw(new Ellipse2D.Float(cx - r * .55f, cy - r * .55f, r * 1.1f, r * 1.1f)); for (int i = 0; i < 8; i++) { double an = i * Math.PI / 4; g.draw(new Line2D.Float(cx + (float) Math.cos(an) * r * .8f, cy + (float) Math.sin(an) * r * .8f, cx + (float) Math.cos(an) * r * 1.1f, cy + (float) Math.sin(an) * r * 1.1f)); } }
                case "grid" -> { float q = r * .85f; g.fill(new Rectangle2D.Float(cx - q, cy - q, q * .9f, q * .9f)); g.fill(new Rectangle2D.Float(cx + q * .1f, cy - q, q * .9f, q * .9f)); g.fill(new Rectangle2D.Float(cx - q, cy + q * .1f, q * .9f, q * .9f)); }
                case "swords" -> { g.draw(new Line2D.Float(cx - r, cy - r, cx + r, cy + r)); g.draw(new Line2D.Float(cx + r, cy - r, cx - r, cy + r)); }
                case "ring" -> g.draw(new Arc2D.Float(cx - r, cy - r, r * 2, r * 2, 20, 300, Arc2D.OPEN));
                default -> { for (int i = 0; i < 5; i++) { double an = i * Math.PI * 2 / 5 - Math.PI / 2; g.fill(new Ellipse2D.Float(cx + (float) Math.cos(an) * r * .6f - r * .35f, cy + (float) Math.sin(an) * r * .6f - r * .35f, r * .7f, r * .7f)); } }
            }
        }
        public void playerHead(float cx, float cy, float size) {
            g.setColor(new Color(0xC8A06A)); g.fill(new Rectangle2D.Float(cx - size / 2, cy - size / 2, size, size));
            g.setColor(new Color(0xE9C46A)); g.fill(new Rectangle2D.Float(cx - size / 2, cy - size / 2, size, size * .35f));
            g.setColor(new Color(0x222222)); g.fill(new Rectangle2D.Float(cx - size * .28f, cy, size * .16f, size * .12f)); g.fill(new Rectangle2D.Float(cx + size * .12f, cy, size * .16f, size * .12f));
        }
        public void frostBackdrop(float amt) {
            // fake "blurred world": blit pre-blurred image with a dark tint
            g.setComposite(AlphaComposite.SrcOver.derive(Math.min(1f, amt)));
            g.drawImage(world, 0, 0, null);
            g.setComposite(AlphaComposite.SrcOver);
            g.setColor(new Color(10, 16, 26, Math.round(110 * amt))); g.fillRect(0, 0, W, H);
        }
        public void pushClip(float x, float y, float w, float h) { g.setClip(new Rectangle2D.Float(x, y, w, h)); }
        public void popClip() { g.setClip(null); }
    }

    record Mod(String name, boolean[] on, List<Model.Setting> st) implements Model.ModuleView {
        public boolean enabled() { return on[0]; } public void setEnabled(boolean v) { on[0] = v; } public List<Model.Setting> settings() { return st; }
    }
    record Tog(String name, boolean[] v) implements Model.ToggleSetting { public boolean get() { return v[0]; } public void set(boolean x) { v[0] = x; } }
    record Sld(String name, double[] v, double min, double max) implements Model.SliderSetting { public double get() { return v[0]; } public void set(double x) { v[0] = x; } }
    record Cho(String name, List<String> options, int[] i) implements Model.ChoiceSetting { public int index() { return i[0]; } public void setIndex(int x) { i[0] = x; } }

    static Mod m(String n, boolean on, Model.Setting... s) { return new Mod(n, new boolean[] { on }, List.of(s)); }

    public static void main(String[] a) throws Exception {
        String mode = a.length > 0 ? a[0] : "wheel";
        BufferedImage world = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        Graphics2D wg = world.createGraphics();
        wg.setPaint(new GradientPaint(0, 0, new Color(0x2B3A5C), 0, H * .55f, new Color(0x5A6F8E))); wg.fillRect(0, 0, W, H);
        wg.setPaint(new GradientPaint(0, H * .5f, new Color(0x2F4A2A), 0, H, new Color(0x1B2B1A))); wg.fillRect(0, (int) (H * .5), W, H);
        wg.dispose();

        List<Model.Category> cats = List.of(
            new Model.Category("Settings", "gear", List.of(m("GUI Theme", true), m("Keybinds", false))),
            new Model.Category("Misc", "grid", List.of(m("Auto Respawn", false))),
            new Model.Category("Combat", "swords", List.of(
                m("Aim Assist", true, new Tog("Only Sword", new boolean[] { true }), new Sld("Range", new double[] { 4.2 }, 1, 6), new Sld("Smoothing", new double[] { 62 }, 0, 100), new Cho("Target", List.of("Players", "Mobs", "All"), new int[] { 0 })),
                m("Reach Display", false), m("Hit Select", true), m("Crit Helper", false), m("Block Timer", false))),
            new Model.Category("Visual", "ring", List.of(m("Fullbright", false))),
            new Model.Category("Client", "flower", List.of(m("Notifications", true))));
        List<Model.QuickButton> q = List.of(new Model.QuickButton("Profiles", () -> {}), new Model.QuickButton("HUD", () -> {}), new Model.QuickButton("GUI Settings", () -> {}), new Model.QuickButton("Configs", () -> {}));

        ScrowMenu menu = new ScrowMenu("Player", "Scrow", "Atmosphere", cats, q, (s, p) -> {});
        menu.resize(W, H);
        int mx = 0, my = 0;
        for (int i = 0; i < 90; i++) menu.update(1 / 60f);
        BufferedImage out = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        J2D d = new J2D(g, world);
        if (mode.equals("combat")) {
            menu.render(d, 0, 0);                       // populate hit boxes
            menu.mouseClicked(W / 2f + 133, H / 2f + 35, 0); // click Combat petal
            for (int i = 0; i < 60; i++) menu.update(1 / 60f);
            menu.render(d, 0, 0);
            menu.mouseClicked(76 + 150, 130 + 30 + 14, 1);   // right-click first module -> settings
            for (int i = 0; i < 60; i++) menu.update(1 / 60f);
            mx = 150; my = 220;
        } else { mx = W / 2 + 133; my = H / 2 + 35; menu.render(new J2D(g, world), mx, my); for (int i = 0; i < 40; i++) menu.update(1 / 60f); }
        g.setComposite(AlphaComposite.Clear); g.fillRect(0, 0, W, H); g.setComposite(AlphaComposite.SrcOver);
        menu.render(d, mx, my); g.dispose();
        ImageIO.write(out, "png", new File("preview_" + mode + ".png"));
        System.out.println("ok " + mode);
    }
}
