package dev.scrow.gui;

import java.util.List;

/** Placeholder categories so the GUI opens out of the box. Replace with views over your real modules. */
public final class DemoData {
    private DemoData() {}

    static final class Mod implements Model.ModuleView {
        private final String name; private boolean on; private final List<Model.Setting> settings;
        Mod(String name, boolean on, Model.Setting... s) { this.name = name; this.on = on; this.settings = List.of(s); }
        public String name() { return name; } public boolean enabled() { return on; }
        public void setEnabled(boolean v) { on = v; } public List<Model.Setting> settings() { return settings; }
    }
    static final class Tog implements Model.ToggleSetting {
        private final String n; private boolean v; Tog(String n, boolean v) { this.n = n; this.v = v; }
        public String name() { return n; } public boolean get() { return v; } public void set(boolean x) { v = x; }
    }
    static final class Sld implements Model.SliderSetting {
        private final String n; private double v, lo, hi; Sld(String n, double v, double lo, double hi) { this.n = n; this.v = v; this.lo = lo; this.hi = hi; }
        public String name() { return n; } public double min() { return lo; } public double max() { return hi; }
        public double get() { return v; } public void set(double x) { v = x; }
    }
    static final class Cho implements Model.ChoiceSetting {
        private final String n; private final List<String> o; private int i; Cho(String n, List<String> o) { this.n = n; this.o = o; }
        public String name() { return n; } public List<String> options() { return o; } public int index() { return i; } public void setIndex(int x) { i = x; }
    }

    public static List<Model.Category> categories() {
        return List.of(
            new Model.Category("Settings", "gear", List.of(new Mod("GUI Theme", true, new Tog("Particles", true), new Sld("Blur", 60, 0, 100)), new Mod("Keybinds", false))),
            new Model.Category("Misc", "grid", List.of(new Mod("Auto Respawn", false))),
            new Model.Category("Combat", "swords", List.of(new Mod("Example Module", true, new Tog("Option", true), new Sld("Range", 4.2, 1, 6), new Cho("Mode", List.of("A", "B", "C"))), new Mod("Another Module", false))),
            new Model.Category("Visual", "ring", List.of(new Mod("Fullbright", false))),
            new Model.Category("Client", "flower", List.of(new Mod("Notifications", true))));
    }

    public static List<Model.QuickButton> buttons() {
        return List.of(new Model.QuickButton("Profiles", () -> {}), new Model.QuickButton("HUD", () -> {}),
            new Model.QuickButton("GUI Settings", () -> {}), new Model.QuickButton("Configs", () -> {}));
    }
}
