package dev.scrow.gui.mc;

import com.mojang.brigadier.Command;
import dev.scrow.gui.DemoData;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.client.Minecraft;

/** Test entrypoint: type /scrowgui in game. In your real client, call the same setScreen line from your own keybind. */
public final class ScrowGuiClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("scrowgui").executes(ctx -> {
                Minecraft mc = Minecraft.getInstance();
                // scheduled so the chat screen doesn't close ours right after the command runs
                mc.schedule(() -> mc.setScreen(new ScrowScreen("Atmosphere", "Scrow", DemoData.categories(), DemoData.buttons())));
                return Command.SINGLE_SUCCESS;
            })));
    }
}
