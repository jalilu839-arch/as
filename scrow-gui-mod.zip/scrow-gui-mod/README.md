# Scrow GUI - Fabric 1.21.11 project

Builds a client-only mod jar containing the radial-wheel GUI. In game, type `/scrowgui` to open it with demo modules.
To use it in your own client, add `src/main/java/dev/scrow/gui` and `src/main/resources/assets/scrowgui` to your client
project and call `mc.setScreen(new ScrowScreen(...))` from your keybind, with `Model.ModuleView` implementations over
your own modules.

## Build in a GitHub Codespace
1. Java 21: `java -version` (if not 21: `sdk list java`, then `sdk install java <a 21 Temurin id>`).
2. This zip has no Gradle wrapper (it is binary and could not be generated offline). Get it from the Fabric template for
   1.21.11 (fabricmc.net/develop/template, Mojang mappings): copy `gradlew`, `gradlew.bat` and the `gradle/` folder into
   this folder, and copy `minecraft_version`, `loader_version`, `loom_version`, `fabric_version` from the template's
   `gradle.properties` over the ones here (mine are unverified guesses).
3. `chmod +x gradlew && ./gradlew build`
4. The jar is `build/libs/scrow-gui-1.0.0.jar` (not the `-sources` one). Download it from the file explorer.
5. Put it in `mods/` with Fabric Loader and Fabric API for 1.21.11.

## Not verified
Only the plain-Java part (`dev.scrow.gui`, `DemoData`) was compiled and run. The `mc` package and the Gradle files
could not be built here (no network or Minecraft jars). If the build prints errors, send me the first lines.
